module.exports = {
  content: [
    "./src/component/navbar.jsx",
    "./src/component/header.jsx",
    "./src/component/statistics.jsx",
    "./src/component/about.jsx",
    "./src/component/menu.jsx",
    "./src/component/contact.jsx",
    "./src/component/footer.jsx",
    "./src/App.js",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
