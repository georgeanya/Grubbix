import React from 'react'

const Team = () => {
  return (
    <div>
        <h3>Our Team</h3>
      <div>
          
      </div>
    </div>
  )
}

export default Team;
