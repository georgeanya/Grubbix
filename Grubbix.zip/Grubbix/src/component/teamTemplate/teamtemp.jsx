// import React from 'react'

// const teamtemp = ({name desc pos }) => {
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default teamtemp
